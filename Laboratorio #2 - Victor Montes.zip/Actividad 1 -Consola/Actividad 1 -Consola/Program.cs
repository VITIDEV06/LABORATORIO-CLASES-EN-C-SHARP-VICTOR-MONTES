﻿using System;

namespace LibroCalificaciones_1
{
    internal class PruebaLibroCalificaciones_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Bienvenido al Libro de calificaciones.");
        }

    }
}